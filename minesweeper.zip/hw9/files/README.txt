=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: shivin
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. 2D Arrays - I use 2D arrays to store the state of the GameCourt in 2 ways. First, there is a 2D
  which models the locations of mines and the number of mines in the neighborhood of each block.
  Secondly, one 2D array keeps track of the blocks that have been revealed, not revealed, or
  flagged. 

  2. Recursion (Game Logic) - Recursion is extremely useful in the game logic for minesweeper. When
  the player reveals a 0 block (a block with no mines in its neighborhood), all blocks in its
  neighborhood are revealed. If one of the blocks in the neighborhood is a 0 block too, then all of
  that block's neighbors are cleared too, and so on.

  3. Collections (Sets) - There are a couple ways I'm using Collections. To decide the locations of
  the 10 mines randomly, I have to generate 10 unique random numbers. In order to do so, I take
  advantage of the feature of sets that sets do not contain duplicate values. So, I keep generating
  random numbers until the size of the set becomes 10. Secondly, I use collections to evaluate the
  the win condition. I have modelled the state of the court by using one collection to keep track of
  mines' locations and one set for the locations of flags. 
  Some of the less-interesting implementations of minesweeper let you win only 
  when you've clicked every block. However, I wanted to let the player win as soon as they place
  all the flags in the place of all the mines. Here again, I use sets to store the locations of all
  the flags and another set to store the locations of all the mines. As soon as these 2 sets become
  equal, the player wins! This implementation makes the experience less annoying for some skilled
  players.

  4. File I/O - I use File I/0 to maintain a leaderboard with data from every time someone has won
  the game. I keep record of the user's username and the number of seconds that user took to win the
  game. I do not keep track of users who lose the game. I parse through the file, sort the users in
  ascending order of their scores (time taken), and display the top 3 (or fewer, if less than 3
  datapoints) players' usernames and scores. I also use File I/O to read the instructions from a
  .txt file which contains the instructions.


=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.

My design is pretty similar to the reference code for Mushroom of Doom provided to us. My Game class
handles most of the Java Swing labels/menus/instructions, and creates an instance of the GameCourt
class. The GameCourt class contains most of the functionality with regards to the actual game. I use
a MouseListener, get the coordinates of the mouse release, and appropriately deal with clicks. It
also contains all my helper functions related to the game playing. I did not use the GameObj class
because I didn't have any moving objects, collisions, etc in my game, so it didn't make sense for
me to use that.

- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?

Without doubt, it was the recursive function which reveals mines (and neighbors of 0 blocks) that
involved the hardest logic. It took a signficiant amount of trial and error, and critical thinking
before I got it right the way I wanted it.

- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?

I think encapsulation is pretty good, I have relevant getters/setters for instance variables and
helper functions are private. A part of me wishes I had made a different tile class, but I do
feel that would've made some things harder. So it was a little tradeoff I had to make in terms of
doing something more OO against something more efficient. But I am happy with my design overall.

========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
  
  Images : https://github.com/pardahlman/minesweeper/tree/master/Images