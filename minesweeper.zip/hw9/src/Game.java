/**
 * CIS 120 Game HW
 * (c) University of Pennsylvania
 * @version 2.1, Apr 2017
 */

// imports necessary libraries for Java swing
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * Game Main class that specifies the frame and widgets of the GUI
 */
public class Game implements Runnable {
    public void run() {
        // NOTE : recall that the 'final' keyword notes immutability even for local variables.

        // Top-level frame in which game components live
        // Be sure to change "TOP LEVEL FRAME" to the name of your game
        final JFrame frame = new JFrame("Shivin Uppal's Minesweeper");
        frame.setSize(306, 306);
        frame.setLocation(306, 306);

        // Status panel
        final JPanel status_panel = new JPanel();
        frame.add(status_panel, BorderLayout.SOUTH);
        final JLabel status = new JLabel("Running...");
        status_panel.add(status);

        final JLabel flags = new JLabel("Flags Left : 10");
        final JLabel time = new JLabel("Time : 0");
        
        // Main playing area
        final GameCourt court = new GameCourt(status, flags, time);
        frame.add(court, BorderLayout.CENTER);

        // Reset button
        final JPanel control_panel = new JPanel();
        frame.add(control_panel, BorderLayout.NORTH);

        // Note here that when we add an action listener to the reset button, we define it as an
        // anonymous inner class that is an instance of ActionListener with its actionPerformed()
        // method overridden. When the button is pressed, actionPerformed() will be called.
        final JButton reset = new JButton();
        try {
            BufferedImage img = ImageIO.read(new File("files/reset.png"));
            reset.setIcon(new ImageIcon(img));
          } catch (Exception e) {
            System.out.println(e);
          }
        reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                court.reset();
            }
        });
        
        
        control_panel.add(flags);
        control_panel.add(reset);
        control_panel.add(time);

        JMenuBar menubar = new JMenuBar();

        JMenu helpMenu = new JMenu("Help");
        
        JMenuItem helpMenuItem = new JMenuItem("Instructions Window");
        
        helpMenuItem.addActionListener((ActionEvent event) -> {
        	JOptionPane.showMessageDialog(null, readInstructions());
        });

        helpMenu.add(helpMenuItem);

        menubar.add(helpMenu);

        frame.setJMenuBar(menubar);

        
        
        
        // Put the frame on the screen
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Start game
        court.reset();
    }
    
    public static String readInstructions() {
    	BufferedReader reader = null;
    	String out = "";
    	try {
    		String curr;
    		reader = new BufferedReader(new FileReader("files/instructions.txt"));
    		while ((curr = reader.readLine()) != null) {
    			out += curr + '\n';
    		}
    	} catch (IOException e) {
    		System.out.println(e);
    	} finally {
    		try {
    			if (reader != null) {
    				reader.close();
    			}
    		} catch (IOException e) {
    			System.out.println(e);
    		}	
    	}
    	return out;
    }

    /**
     * Main method run to start and run the game. Initializes the GUI elements specified in Game and
     * runs it. IMPORTANT: Do NOT delete! You MUST include this in your final submission.
     */
    public static void main(String[] args) {
    	try {
	    	String username = JOptionPane.showInputDialog(null, 
	    			"Choose a username. (upto 6 characters)", "USERNAME",
	    			JOptionPane.QUESTION_MESSAGE);
	    	while (username.length() > 6) {
	    		username = JOptionPane.showInputDialog(null, 
	        			"Choose a username. (upto 6 characters) (ENTERED INVALID NAME)", 
	        			"USERNAME", JOptionPane.QUESTION_MESSAGE);
	    	}
	    	GameCourt.setUsername(username);
	        SwingUtilities.invokeLater(new Game());
    	} catch (NullPointerException e) {
    		System.out.println("Username not entered by user");
    	}

    }
}